import os
from flask import Flask, request
import telegram
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_TOKEN")
USER_ID = os.getenv("TELEGRAM_USER_ID")

bot = telegram.Bot(token=TOKEN)
app = Flask(__name__)

@app.route('/')
def home():
    return 'Bot is running!'

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.get_json()
    message = data.get("message", "No message received")
    bot.send_message(chat_id=USER_ID, text=f"📢 Forex Signal:\n{message}")
    return "OK", 200

if __name__ == '__main__':
    app.run(debug=True)
