import os
import logging
import asyncio
import yfinance as yf
import pandas as pd
import matplotlib.pyplot as plt
from datetime import datetime
from telegram import Update, InputFile
from telegram.ext import Application, CommandHandler, ContextTypes
from dotenv import load_dotenv

# Load .env variables
load_dotenv()
TOKEN = os.getenv("TELEGRAM_TOKEN")
ADMIN_ID = int(os.getenv("ADMIN_ID"))

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Default pairs
DEFAULT_PAIRS = [
    "EURUSD=X", "GBPUSD=X", "USDJPY=X", "USDCHF=X", "USDCAD=X",
    "AUDUSD=X", "NZDUSD=X", "EURJPY=X", "GBPJPY=X", "XAUUSD=X"
]

# Signal logic (EMA crossover)
def get_signal(pair):
    try:
        df = yf.download(pair, period="7d", interval="1h")
        df['EMA9'] = df['Close'].ewm(span=9).mean()
        df['EMA20'] = df['Close'].ewm(span=20).mean()
        latest = df.iloc[-1]
        prev = df.iloc[-2]

        signal = None
        if prev['EMA9'] < prev['EMA20'] and latest['EMA9'] > latest['EMA20']:
            signal = "BUY"
        elif prev['EMA9'] > prev['EMA20'] and latest['EMA9'] < latest['EMA20']:
            signal = "SELL"

        # Plot chart
        fig, ax = plt.subplots()
        df[-50:]['Close'].plot(ax=ax, label='Price', color='black')
        df[-50:]['EMA9'].plot(ax=ax, label='EMA9', color='blue')
        df[-50:]['EMA20'].plot(ax=ax, label='EMA20', color='red')
        ax.set_title(pair)
        ax.legend()
        image_path = f"{pair.replace('=X', '')}_chart.png"
        plt.savefig(image_path)
        plt.close()

        return signal, latest['Close'], image_path

    except Exception as e:
        logger.error(f"Error fetching signal for {pair}: {e}")
        return None, None, None

# Signal command
async def signal_command(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.effective_user.id != ADMIN_ID:
        await update.message.reply_text("⛔ You are not authorized to use this bot.")
        return

    pairs = context.args if context.args else DEFAULT_PAIRS
    for pair in pairs:
        symbol = pair if "=X" in pair else f"{pair}=X"
        signal, price, chart = get_signal(symbol)
        if signal:
            msg = f"📊 *{pair}* | Signal: *{signal}*
💰 Price: {price:.5f}
🎯 Target: {price*1.003:.5f}
🛑 SL: {price*0.997:.5f}"
        else:
            msg = f"ℹ️ *{pair}* - No signal currently."
        await update.message.reply_photo(photo=InputFile(chart), caption=msg, parse_mode="Markdown")

# Background task: auto signal every hour
async def auto_signal_task(app):
    while True:
        try:
            for pair in DEFAULT_PAIRS:
                signal, price, chart = get_signal(pair)
                if signal:
                    msg = f"🕐 *Auto Signal - {pair.replace('=X', '')}*
📈 *{signal}*
💰 {price:.5f}
🎯 {price*1.003:.5f}
🛑 {price*0.997:.5f}"
                    await app.bot.send_photo(chat_id=ADMIN_ID, photo=InputFile(chart), caption=msg, parse_mode="Markdown")
        except Exception as e:
            logger.error(f"Auto signal error: {e}")
        await asyncio.sleep(3600)

# Main bot
async def main():
    app = Application.builder().token(TOKEN).build()
    app.add_handler(CommandHandler("signal", signal_command))
    app.create_task(auto_signal_task(app))
    await app.run_polling()

if __name__ == "__main__":
    asyncio.run(main())